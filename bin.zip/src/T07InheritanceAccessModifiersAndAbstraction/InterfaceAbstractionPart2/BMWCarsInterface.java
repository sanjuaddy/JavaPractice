package T07InheritanceAccessModifiersAndAbstraction.InterfaceAbstractionPart2;

public interface BMWCarsInterface {
	
	public void headsUpNavigation();

}