package T07InheritanceAccessModifiersAndAbstraction.InterfaceAbstractionPart2;

public class InterfaceDemoInstance {

	public static void main(String[] args) {
		CarsInterface myInterface = new InterfaceDemo();
		myInterface.engineStart("6 Cyl", true);
	}
}