package T01JavaConceptsDataTypes.DefaultVariableValues;

public class DefaultVariableValues {
	
	static byte byteVariable; //size is 1 byte // Byte
	static short shortVariable; //short s = 20000 //2 byte // Short
	static int integerVariable; // int a //4 byte //Integer
	static long longVariable; // long a = 3000000L //8 byte // Long
	static float floatVariable; // float f1 = 101.1f --> 101.19f --> 101.2f //4 byte // Float
	static double doubleVariable; // double d1 = 73.378 //8 byte // Double
	static boolean booleanVariable; //true or false //1 bit // Boolean
	static char charVariable; //a-zA-Z  char alphabet = 'a'// 2 byte // Character
	
	public static void main(String[] args) {
		System.out.println("Byte Value: " + byteVariable);
		System.out.println("Short Value: " + shortVariable);
		System.out.println("Int Value: " + integerVariable);
		System.out.println("Long Value: " + longVariable);
		System.out.println("Float Value: " + floatVariable);
		System.out.println("Double Value: " + doubleVariable);
		System.out.println("Boolean Value: " + booleanVariable);
		System.out.println("Char Value: " + charVariable);
	}
	
	public static void oneMoreMethod() {
		System.out.println("Int Value: " + integerVariable);
	}
}