package T01JavaConceptsDataTypes.FirstProgram;

public class HelloWorld {

	public static void main(String[] args) {
		// This is my 1st Java Program
		/*
		 * This
		 * is
		 * my
		 * 1st Java Program
		 */
		
		//JDK contains a JRE(=private Java Virtual Machine (JVM)) and 
		//a few other resources such as an interpreter/loader (java), 
		//a compiler (javac), an archiver (jar), a documentation generator (Javadoc)//
		
		System.out.println("Hello Word!");
	}
}