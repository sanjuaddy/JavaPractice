package T02ClassesAndMethodsObjectOrientedConcepts.MethodsIntroduction;

public class MethodsDemo {

	public static void main(String[] args) {
		String a = "Hey, there !!!";
		System.out.println(a);
		MethodsDemo md = new MethodsDemo();
		methodNum();
		md.methodStr();
	}
	
	public static void methodNum() {
		String a = "Hey, there !!!";
		System.out.println(a);
	}
	
	public void methodStr() {
		String a = "Hey, Kalpana !!!";
		System.out.println(a);
	}
}