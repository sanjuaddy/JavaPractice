package T03GettersAndSettersPracticalExamples.GettersSettersAndThisKeywordPart1;

public class ClassDemo {

	public static void main(String[] args) {
		Car bmw = new Car(); // Create and initialize the object
		bmw.setMake("BMW");
		System.out.println(bmw.getMake());
	}
}